/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * CurrentDateIndicator
 *
 * (c) 2010-2016 Lars A. V. Cabrera
 *
 * --- WORK IN PROGRESS ---
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/CurrentDateIndicator.js';
