/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 *
 * (c) 2009-2016 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import Highcharts from './highcharts.src.js';
import './modules/stock.src.js';
export default Highcharts;
